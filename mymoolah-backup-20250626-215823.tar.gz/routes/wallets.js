const express = require('express');
const router = express.Router();
const walletModel = require('../models/walletModel');

// Create a wallet
router.post('/', async (req, res) => {
  try {
    const { user_id, account_number } = req.body;
    if (!user_id) {
      return res.status(400).json({ error: 'user_id is required' });
    }
    // Generate a unique account number if not provided
    const acctNum = account_number || `WALLET${Date.now()}${Math.floor(Math.random() * 1000)}`;
    const result = await walletModel.createWallet(user_id, acctNum);
    res.status(201).json({ wallet_id: result.walletId, account_number: result.accountNumber });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get wallet info by ID
router.get('/:id', (req, res) => {
  // TODO: Implement get wallet info logic
  res.json({ message: 'Get wallet info endpoint (not yet implemented)' });
});

// Get wallet balance by ID
router.get('/:id/balance', (req, res) => {
  // TODO: Implement get wallet balance logic
  res.json({ message: 'Get wallet balance endpoint (not yet implemented)' });
});

// Credit wallet
router.post('/:id/credit', (req, res) => {
  // TODO: Implement credit wallet logic
  res.json({ message: 'Credit wallet endpoint (not yet implemented)' });
});

// Debit wallet
router.post('/:id/debit', (req, res) => {
  // TODO: Implement debit wallet logic
  res.json({ message: 'Debit wallet endpoint (not yet implemented)' });
});

// List wallet transactions
router.get('/:id/transactions', (req, res) => {
  // TODO: Implement list wallet transactions logic
  res.json({ message: 'List wallet transactions endpoint (not yet implemented)' });
});

module.exports = router;