   module.exports = {
     testPathIgnorePatterns: ["/node_modules/", "/client/"]
   };