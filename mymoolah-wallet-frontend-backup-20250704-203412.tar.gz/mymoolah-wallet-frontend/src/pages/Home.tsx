// src/pages/Home.tsx
import { Link, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';

/**
 * Landing page for unauthenticated users.
 */
export default function Home() {
  const navigate = useNavigate();
  const isLoggedIn = Boolean(localStorage.getItem('authToken'));
  const isRegistered = Boolean(localStorage.getItem('isRegistered'));

  useEffect(() => {
    if (isLoggedIn) navigate('/dashboard');
  }, [isLoggedIn, navigate]);

  return (
    // Full‐screen grey background, center card
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      {/* Fixed 320px width (w-80), full viewport height minus padding */}
      <div className="w-80 h-[calc(100vh-4rem)] bg-gradient-to-br from-blue-500 to-green-400 rounded-lg shadow-lg overflow-hidden flex flex-col justify-between mx-4 my-4">
        {/* Header area */}
        <div className="px-4 pt-6 text-center">
          <img src="/MyMoolahLogo1.svg" alt="MyMoolah Logo" className="h-16 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-white mb-2">
            Hello – Welcome to MyMoolah!
          </h1>
          <p className="text-sm text-white/80">
            Africa's modern, data-efficient digital wallet
          </p>
        </div>

        {/* Button area */}
        <div className="px-4 pb-6 flex flex-col gap-3">
          <Link to="/login" className="block">
            <button className="w-full py-2 bg-white text-[#2D8CCA] font-semibold rounded-lg shadow hover:bg-[#86BE41] hover:text-white transition">
              Login
            </button>
          </Link>
          {!isRegistered && (
            <Link to="/register" className="block">
              <button className="w-full py-2 bg-[#2D8CCA] text-white font-semibold rounded-lg shadow hover:bg-[#86BE41] transition">
                Register
              </button>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
