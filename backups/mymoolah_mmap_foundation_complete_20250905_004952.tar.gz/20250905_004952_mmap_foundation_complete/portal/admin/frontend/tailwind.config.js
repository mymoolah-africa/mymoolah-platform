/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "../../shared/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        primary: {
          DEFAULT: "var(--primary)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          foreground: "var(--secondary-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          foreground: "var(--accent-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
        mymoolah: {
          green: "var(--mymoolah-green)",
          blue: "var(--mymoolah-blue)",
        },
        portal: {
          admin: "var(--portal-admin)",
          supplier: "var(--portal-supplier)",
          client: "var(--portal-client)",
          merchant: "var(--portal-merchant)",
          reseller: "var(--portal-reseller)",
        },
        success: "var(--success-color)",
        error: "var(--error-color)",
        warning: "var(--warning-color)",
        info: "var(--info-color)",
        "gray-text": "var(--gray-text)",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
      },
      spacing: {
        'portal-xs': 'var(--space-xs)',
        'portal-sm': 'var(--space-sm)',
        'portal-md': 'var(--space-md)',
        'portal-lg': 'var(--space-lg)',
        'portal-xl': 'var(--space-xl)',
        'portal-2xl': 'var(--space-2xl)',
      },
      boxShadow: {
        'portal': 'var(--portal-shadow)',
        'portal-lg': 'var(--portal-shadow-lg)',
      },
      maxWidth: {
        'portal': 'var(--portal-max-width)',
      },
      width: {
        'portal-sidebar': 'var(--portal-sidebar-width)',
      },
      height: {
        'portal-header': 'var(--portal-header-height)',
      },
    },
  },
  plugins: [],
}
