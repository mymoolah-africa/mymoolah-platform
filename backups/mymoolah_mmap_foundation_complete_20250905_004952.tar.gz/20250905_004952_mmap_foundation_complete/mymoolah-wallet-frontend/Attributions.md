This Figma Make file includes components from [shadcn/ui](https://ui.shadcn.com/) used under [MIT license](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

This Figma Make file includes photos from [Unsplash](https://unsplash.com) used under [license](https://unsplash.com/license).

No new libraries were added for user name or greeting logic. All logic uses standard React and API integration.

- [2025-07-23] RegisterPage.tsx is the Figma-generated version, restored for full styling and UX.
- No new libraries or patterns introduced in this update.