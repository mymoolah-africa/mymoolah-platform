// Load environment variables and security configuration
require('dotenv').config();
const securityConfig = require('./config/security');

// Process error handling
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
});
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  process.exit();
});

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const {
  rateLimiters,
  securityHeaders,
  inputValidation,
  handleValidationErrors,
  requestLogger,
  securityMonitor,
  corsConfig
} = require('./middleware/securityMiddleware');
const { secureLogging, secureErrorLogging } = require('./middleware/secureLogging');
const app = express();

// Get configuration from security config
const config = securityConfig.getConfig();
const port = config.port || 3001; // Changed fallback port to 3001

// Import core routes
const authRoutes = require('./routes/auth.js');
const walletRoutes = require('./routes/wallets.js');
const transactionRoutes = require('./routes/transactionRoutes.js');
const userRoutes = require('./routes/users.js');
const kycRoutes = require('./routes/kyc.js');
const supportRoutes = require('./routes/support.js');
const feedbackRoutes = require('./routes/feedbackRoutes.js');
const googleReviewRoutes = require('./routes/googleReviewRoutes.js');
const notificationRoutes = require('./routes/notifications.js');
const voucherRoutes = require('./routes/vouchers.js');
const voucherTypeRoutes = require('./routes/voucherTypes.js');
// Temporarily commented out to fix startup issue
const peachRoutes = require('./routes/peach.js');
// VAS routes removed - functionality handled by airtime routes
const merchantRoutes = require('./routes/merchants.js');
const serviceProviderRoutes = require('./routes/serviceproviders.js');
const easyPayRoutes = require('./routes/easypay.js'); // <-- ADD THIS
const dtMercuryRoutes = require('./routes/dtmercury.js');
const ledgerRoutes = require('./routes/ledger.js');
const settingsRoutes = require('./routes/settings.js');
const supplierComparisonRoutes = require('./routes/supplierComparison.js');
const qrPaymentRoutes = require('./routes/qrpayments.js');
const requestRoutes = require('./routes/requests.js');
const requestScheduler = require('./services/requestScheduler');
const CatalogSynchronizationService = require('./services/catalogSynchronizationService');
const sweepRoutes = require('./routes/sweep.js');

const sendMoneyRoutes = require('./routes/sendMoney.js');
const beneficiariesRoutes = require('./routes/beneficiaries.js');
const unifiedBeneficiariesRoutes = require('./routes/unifiedBeneficiaries.js');
const airtimeRoutes = require('./routes/airtime.js');
const overlayRoutes = require('./routes/overlayServices.js');
const productRoutes = require('./routes/products.js');
const catalogSyncRoutes = require('./routes/catalogSync.js');
const userFavoritesRoutes = require('./routes/userFavorites.js');

// Validate external service credentials
const validCredentials = securityConfig.validateExternalCredentials();

// Conditionally load Flash routes
let flashRoutesLoaded = false;
let flashRoutes;
if (validCredentials.flash) {
  flashRoutes = require('./routes/flash.js');
  flashRoutesLoaded = true;
  console.log('✅ Flash routes loaded');
} else {

}

// Conditionally load MobileMart routes
let mobilemartRoutesLoaded = false;
let mobilemartRoutes;
if (validCredentials.mobilemart) {
  mobilemartRoutes = require('./routes/mobilemart.js');
  mobilemartRoutesLoaded = true;
  console.log('✅ MobileMart routes loaded');
} else {

}



// Security Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  noSniff: true,
  xssFilter: true,
  frameguard: {
    action: 'deny'
  }
}));

// Apply additional security headers
Object.entries(config.securityHeaders).forEach(([header, value]) => {
  app.use((req, res, next) => {
    res.setHeader(header, value);
    next();
  });
});

// Add request logging middleware
app.use((req, res, next) => {
  console.log(`🌐 ${req.method} ${req.url} - ${new Date().toISOString()}`);
  next();
});

// Add a simple test route
app.get('/test', (req, res) => {
  console.log('🧪 Test route hit!');
  res.json({ message: 'Test route working', timestamp: new Date().toISOString() });
});

// Rate Limiting Middleware
const limiter = rateLimit({
  windowMs: config.rateLimits.general.windowMs,
  max: config.rateLimits.general.max,
  message: config.rateLimits.general.message,
  standardHeaders: true,
  legacyHeaders: false,
  // In development, and for CORS preflight, skip limiting to avoid false CORS failures during polling
  skip: (req) => req.method === 'OPTIONS' || (process.env.NODE_ENV && process.env.NODE_ENV !== 'production'),
  handler: (req, res) => {
    res.status(429).json({
      success: false,
      message: config.rateLimits.general.message,
      retryAfter: Math.ceil(config.rateLimits.general.windowMs / 1000)
    });
  }
});

// Apply rate limiting to all routes
app.use(limiter);

// Stricter rate limiting for authentication endpoints
const authLimiter = rateLimit({
  windowMs: config.rateLimits.auth.windowMs,
  max: config.rateLimits.auth.max,
  message: config.rateLimits.auth.message,
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.method === 'OPTIONS' || (process.env.NODE_ENV && process.env.NODE_ENV !== 'production'),
  handler: (req, res) => {
    res.status(429).json({
      success: false,
      message: config.rateLimits.auth.message,
      retryAfter: Math.ceil(config.rateLimits.auth.windowMs / 1000)
    });
  }
});

// Input Validation Middleware
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map(error => ({
        field: error.path,
        message: error.msg,
        value: error.value
      }))
    });
  }
  next();
};

// Validation Schemas
const validateEmail = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  validateRequest
];

const validatePhone = [
  body('phone')
    .matches(/^\+?[1-9]\d{1,14}$/)
    .withMessage('Please provide a valid phone number'),
  validateRequest
];

const validateAmount = [
  body('amount')
    .isFloat({ min: 0.01 })
    .withMessage('Amount must be a positive number greater than 0'),
  validateRequest
];

const validateUserId = [
  body('userId')
    .isInt({ min: 1 })
    .withMessage('User ID must be a positive integer'),
  validateRequest
];

const validateString = (fieldName, minLength = 1, maxLength = 255) => [
  body(fieldName)
    .isLength({ min: minLength, max: maxLength })
    .trim()
    .escape()
    .withMessage(`${fieldName} must be between ${minLength} and ${maxLength} characters`),
  validateRequest
];

// Enhanced Security Middleware
app.use(securityHeaders);
app.use(cors(corsConfig));
app.use(express.json({ limit: '10mb' }));
app.use(secureLogging);
app.use(requestLogger);
app.use(securityMonitor);

// Enhanced Rate Limiting
app.use('/api/v1/auth', rateLimiters.auth);
app.use('/api/v1/transactions', rateLimiters.transactions);
app.use('/api/v1/vas', rateLimiters.vas);
app.use('/api/v1/support', rateLimiters.support);
app.use('/api/v1', rateLimiters.general);

// Core API Routes
app.use('/api/v1/auth', authLimiter, authRoutes);
app.use('/api/v1/wallets', walletRoutes);
app.use('/api/v1/transactions', transactionRoutes);
app.use('/api/v1/users', userRoutes);
app.use('/api/v1/kyc', kycRoutes);
app.use('/api/v1/settings', settingsRoutes);
app.use('/api/v1/send-money', sendMoneyRoutes);
app.use('/api/v1/beneficiaries', beneficiariesRoutes);
app.use('/api/v1/unified-beneficiaries', unifiedBeneficiariesRoutes);
app.use('/api/v1/airtime', airtimeRoutes);
app.use('/api/v1/overlay', overlayRoutes);
app.use('/api/v1/products', productRoutes);
app.use('/api/v1/catalog-sync', catalogSyncRoutes);
try {
  app.use('/api/v1/favorites', userFavoritesRoutes);
  console.log('   - Favorites: /api/v1/favorites');
} catch (error) {
  console.error('❌ Error loading favorites routes:', error.message);
}
app.use('/api/v1/support', supportRoutes);
app.use('/api/v1/feedback', feedbackRoutes);
app.use('/api/v1/google-reviews', googleReviewRoutes);
app.use('/api/v1/notifications', notificationRoutes);
app.use('/api/v1/vouchers', voucherRoutes);
app.use('/api/v1/voucher-types', voucherTypeRoutes);
// Temporarily commented out to fix startup issue
app.use('/api/v1/peach', peachRoutes);
// VAS routes removed - functionality handled by airtime routes
app.use('/api/v1/merchants', merchantRoutes);
app.use('/api/v1/service-providers', serviceProviderRoutes);
app.use('/billpayment/v1', easyPayRoutes);
app.use('/api/v1/dtmercury', dtMercuryRoutes);
app.use('/api/v1/ledger', ledgerRoutes);
if (flashRoutesLoaded) {
  app.use('/api/v1/flash', flashRoutes);
}
if (mobilemartRoutesLoaded) {
  app.use('/api/v1/mobilemart', mobilemartRoutes);
}

// Supplier Comparison Routes (always available)
app.use('/api/v1/suppliers', supplierComparisonRoutes);

// QR Payment Routes
app.use('/api/v1/qr', qrPaymentRoutes);
app.use('/api/v1/requests', requestRoutes);

// Codebase Sweep Routes
app.use('/api/v1/sweep', sweepRoutes);

// Performance Monitoring Routes
app.use('/api/v1/monitoring', require('./routes/monitoring'));



// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0'
  });
});

// Start server
app.listen(port, () => {
  console.log("Starting server...");
  console.log(`🚀 MyMoolah Wallet API server running on port ${port}`);
  console.log(`📡 API Base URL: http://localhost:${port}/api/v1`);
  console.log(`🔗 Health Check: http://localhost:${port}/health`);
  console.log(`📋 Available endpoints:`);
  console.log(`   - Auth: /api/v1/auth`);
  console.log(`   - Wallets: /api/v1/wallets`);
  console.log(`   - Transactions: /api/v1/transactions`);
  console.log(`   - Users: /api/v1/users`);
  console.log(`   - KYC: /api/v1/kyc`);
  console.log(`   - Settings: /api/v1/settings`);
  console.log(`   - Support: /api/v1/support`);
  console.log(`   - Feedback: /api/v1/feedback`);
  console.log(`   - Google Reviews: /api/v1/google-reviews`);
  console.log(`   - Notifications: /api/v1/notifications`);
  console.log(`   - Vouchers: /api/v1/vouchers`);
  console.log(`   - Voucher Types: /api/v1/voucher-types`);
  console.log(`   - Airtime: /api/v1/airtime`);
console.log(`   - Merchants: /api/v1/merchants`);
console.log(`   - Service Providers: /api/v1/service-providers`);
console.log(`   - EasyPay: /billpayment/v1`);
console.log(`   - dtMercury: /api/v1/dtmercury`);
console.log(`   - Ledger: /api/v1/ledger`);
if (flashRoutesLoaded) {
console.log(`   - Flash: /api/v1/flash`);
}
if (mobilemartRoutesLoaded) {
console.log(`   - MobileMart: /api/v1/mobilemart`);
}
console.log(`   - Supplier Comparison: /api/v1/suppliers`);
console.log(`   - QR Payments: /api/v1/qr`);
console.log(`   - Requests: /api/v1/requests`);
console.log(`   - Codebase Sweep: /api/v1/sweep`);
console.log(`   - Performance Monitoring: /api/v1/monitoring`);
console.log(`   - Products: /api/v1/products`);
console.log(`   - Catalog Sync: /api/v1/catalog-sync`);
console.log(`   - Favorites: /api/v1/favorites`);
  
  // Start EasyPay expiration handler (env-gated)
  const expiryToggle = String(process.env.EASYPAY_EXPIRY_HANDLER_ENABLED || '').trim().toLowerCase();
  if (expiryToggle === 'true' || expiryToggle === '1' || expiryToggle === 'yes') {
    try {
      const { startExpirationHandler } = require('./controllers/voucherController');
      startExpirationHandler();
    } catch (error) {
      console.error('❌ Failed to start EasyPay expiration handler:', error);
    }
  } else {
    console.log('⏸️  EasyPay expiration handler disabled by EASYPAY_EXPIRY_HANDLER_ENABLED');
  }

  // Start recurring request scheduler (env-gated)
  const recurringToggle = String(process.env.RECURRING_REQUESTS_ENABLED || 'true').trim().toLowerCase();
  if (recurringToggle === 'true' || recurringToggle === '1' || recurringToggle === 'yes') {
    try {
      requestScheduler.start();
      console.log('✅ Recurring Request Scheduler: Started');
    } catch (e) {
      console.error('❌ Failed to start Recurring Request Scheduler:', e);
    }
  } else {
    console.log('⏸️  Recurring Request Scheduler disabled by RECURRING_REQUESTS_ENABLED');
  }

  // Start database performance monitoring
  const databasePerformanceMonitor = require('./services/databasePerformanceMonitor');
  databasePerformanceMonitor.startMonitoring()
    .catch((error) => {
      console.error('❌ Failed to start database monitoring:', error.message);
    });

  // Start caching service
  const cachingService = require('./services/cachingService');
  console.log('✅ Caching service initialized');

  // Start catalog synchronization service (env-gated)
  const catalogSyncToggle = String(process.env.CATALOG_SYNC_ENABLED || 'true').trim().toLowerCase();
  if (catalogSyncToggle === 'true' || catalogSyncToggle === '1' || catalogSyncToggle === 'yes') {
    try {
      const catalogSyncService = new CatalogSynchronizationService();
      catalogSyncService.start();
      console.log('✅ Catalog Synchronization Service: Started');
    } catch (e) {
      console.error('❌ Failed to start Catalog Synchronization Service:', e);
    }
  } else {
    console.log('⏸️  Catalog Synchronization Service disabled by CATALOG_SYNC_ENABLED');
  }
});

module.exports = app; // Export the app for testing